'use client';

import { useEffect } from 'react';

export default function LanguageSwitcher() {
  useEffect(() => {
    const english = window.location.pathname === '/en' || window.location.pathname.startsWith('/en/');
    const target = document.querySelector<HTMLElement>('header > div > div:last-child');
    if (!target || target.querySelector('[data-language-switcher]')) return;
    const link = document.createElement('a');
    link.dataset.languageSwitcher = 'true';
    link.href = english ? window.location.pathname.replace(/^\/en/, '') || '/' : `/en${window.location.pathname === '/' ? '' : window.location.pathname}`;
    link.textContent = english ? 'FR' : 'EN';
    link.title = english ? 'Version française' : 'English version';
    link.className = 'rounded-xl border border-[#17342d]/15 px-3 py-2 text-sm font-bold hover:bg-[#e8eee9]';
    target.prepend(link);
  }, []);
  return null;
}
