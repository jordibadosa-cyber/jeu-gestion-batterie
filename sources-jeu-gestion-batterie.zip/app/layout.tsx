import type { Metadata } from 'next';
import { Geist, Geist_Mono } from 'next/font/google';
import './globals.css';
import LanguageSwitcher from '@/components/LanguageSwitcher';

const geistSans = Geist({
  variable: '--font-geist-sans',
  subsets: ['latin'],
});

const geistMono = Geist_Mono({
  variable: '--font-geist-mono',
  subsets: ['latin'],
});

export const metadata: Metadata = {
  title: 'Jeu de gestion de batterie',
  description: 'Exercice interactif de pilotage énergétique pour comprendre le rôle d’un EMS et la valeur de la prévision solaire.',
  openGraph: {
    title: 'Jeu de gestion de batterie',
    description: 'Pilotez une batterie heure par heure et comparez votre stratégie à celle d’un EMS.',
    images: ['/og.png'],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Jeu de gestion de batterie',
    description: 'Pilotez une batterie heure par heure et comparez votre stratégie à celle d’un EMS.',
    images: ['/og.png'],
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fr">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased`}
      >
        <LanguageSwitcher />
        {children}
      </body>
    </html>
  );
}
