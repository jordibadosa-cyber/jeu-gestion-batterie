'use client';

import FrenchDocumentation from '../../documentation/page';
import { useEnglishTranslations } from '@/lib/english';

export default function EnglishDocumentation() {
  useEnglishTranslations();
  return <FrenchDocumentation />;
}
