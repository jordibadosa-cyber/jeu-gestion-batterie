'use client';

import FrenchGame from '../page';
import { useEnglishTranslations } from '@/lib/english';

export default function EnglishGame() {
  useEnglishTranslations();
  return <FrenchGame />;
}
