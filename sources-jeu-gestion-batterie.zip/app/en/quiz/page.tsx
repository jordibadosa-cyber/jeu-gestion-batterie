'use client';

import FrenchQuiz from '../../quiz/page';
import { useEnglishTranslations } from '@/lib/english';

export default function EnglishQuiz() {
  useEnglishTranslations();
  return <FrenchQuiz />;
}
