'use client';

import { useEffect, useMemo, useState } from 'react';
import { BatteryMedium, BookOpen, Building2, CloudSun, Eye, Gauge, Grid3X3, Lightbulb, RotateCcw, Sun } from 'lucide-react';

type Action='charge'|'idle'|'discharge';
type Objective='cost'|'carbon'|'autonomy';
type Result={hour:number;load:number;pv:number;action:Action;batteryPower:number;soc:number;grid:number;cost:number;co2:number;curtailed:number};
type Scenario={name:string;subtitle:string;weather:string;load:number[];pv:number[];forecast:number[];price:number[];carbon:number[]};
const HOURS=Array.from({length:24},(_,i)=>i);
const full=(day:number[],before:number[],after:number[])=>[...before,...day,...after];
const SCENARIOS:Record<string,Scenario>={
  variable:{name:'Journée variable',subtitle:'Front nuageux imprévisible',weather:'Passage nuageux probable entre 13h et 16h · incertitude ± 12 kW',load:full([24,29,34,39,42,38,36,40,46,52,42,30],[18,16,15,14,14,15,18,22],[26,22,20,19]),pv:full([4,12,24,38,47,31,7,11,18,11,3,0],Array(8).fill(0),Array(4).fill(0)),forecast:full([5,14,27,40,46,40,31,24,17,9,2,0],Array(8).fill(0),Array(4).fill(0)),price:full([.14,.14,.16,.18,.18,.18,.22,.28,.38,.42,.31,.22],[.10,.10,.09,.09,.10,.11,.13,.14],[.18,.15,.13,.11]),carbon:full([42,39,35,31,29,32,38,57,86,102,91,69],[55,51,48,45,43,42,41,42],[59,55,52,50])},
  sunny:{name:'Journée ensoleillée',subtitle:'Surplus solaire à midi',weather:'Ciel clair, quelques voiles élevés · incertitude ± 5 kW',load:full([22,27,33,38,41,37,35,39,45,51,40,29],[16,15,14,13,13,14,16,20],[24,20,18,17]),pv:full([5,16,31,48,58,61,57,48,34,17,5,0],Array(8).fill(0),Array(4).fill(0)),forecast:full([6,18,34,50,60,63,59,50,36,19,6,0],Array(8).fill(0),Array(4).fill(0)),price:full([.13,.13,.15,.17,.17,.18,.22,.29,.39,.43,.32,.22],[.09,.09,.09,.09,.10,.11,.12,.13],[.17,.14,.12,.10]),carbon:full([45,41,36,31,27,25,29,44,75,98,87,66],[50,48,45,42,40,39,40,43],[55,51,48,46])},
  winter:{name:'Journée d’hiver',subtitle:'PV faible, pointe marquée',weather:'Éclaircies courtes vers midi · incertitude ± 7 kW',load:full([31,38,42,44,46,43,42,47,55,62,53,41],[27,25,24,23,23,25,29,34],[35,31,29,28]),pv:full([1,3,7,13,19,22,17,10,5,2,0,0],Array(8).fill(0),Array(4).fill(0)),forecast:full([1,4,9,16,23,25,21,14,7,2,0,0],Array(8).fill(0),Array(4).fill(0)),price:full([.16,.18,.21,.22,.20,.19,.24,.34,.48,.51,.39,.27],[.13,.12,.12,.12,.13,.14,.16,.18],[.23,.20,.17,.15]),carbon:full([58,55,48,43,39,41,53,79,121,138,112,84],[70,66,62,58,55,54,56,60],[77,72,68,65])},
};
const REFERENCE_CAPACITY=80,MIN_SOC_RATIO=.1,INITIAL_SOC_RATIO=.45,MAX_POWER=25,EFF=.94,PV_REFERENCE_KWP=50;
const LABELS:Record<Action,string>={charge:'Charger',idle:'Attendre',discharge:'Décharger'};
const OBJECTIVES:Record<Objective,string>={cost:'Réduire le coût',carbon:'Réduire le CO₂',autonomy:'Maximiser l’autonomie'};
const fmt=(v:number,d=1)=>v.toLocaleString('fr-FR',{maximumFractionDigits:d,minimumFractionDigits:d});

function runStep(s:Scenario,i:number,soc:number,action:Action,requestedPower=MAX_POWER,capacity=REFERENCE_CAPACITY,reserveRatio=MIN_SOC_RATIO):Result{
  const net=s.load[i]-s.pv[i];let power=0;
  const minSoc=capacity*reserveRatio;
  const setpoint=Math.max(0,Math.min(MAX_POWER,requestedPower));
  if(action==='charge')power=-Math.min(setpoint,(capacity-soc)/EFF);
  if(action==='discharge')power=Math.min(setpoint,Math.max(0,(soc-minSoc)*EFF));
  const next=action==='charge'?soc+-power*EFF:soc-power/EFF,grid=net-power;
  return {hour:HOURS[i],load:s.load[i],pv:s.pv[i],action,batteryPower:power,soc:Math.max(minSoc,Math.min(capacity,next)),grid,cost:Math.max(0,grid)*s.price[i]-Math.max(0,-grid)*.06,co2:Math.max(0,grid)*s.carbon[i],curtailed:Math.max(0,-grid)};
}
function objectiveValue(r:Result,o:Objective){return o==='cost'?r.cost:o==='carbon'?r.co2/1000:Math.max(0,r.grid)}
function optimalPlan(s:Scenario,o:Objective,capacity=REFERENCE_CAPACITY){
  const memo=new Map<string,{score:number;path:Result[]}>();
  const initialSoc=capacity*INITIAL_SOC_RATIO;
  const choices=[{action:'idle' as Action,power:0},...([5,10,15,20,25].flatMap(power=>[{action:'charge' as Action,power},{action:'discharge' as Action,power}]))];
  const solve=(i:number,soc:number):{score:number;path:Result[]}=>{if(i===HOURS.length){const deficit=Math.max(0,initialSoc-soc);return {score:o==='cost'?deficit*.18:o==='carbon'?deficit*.055:deficit,path:[]}};const key=`${i}-${Math.round(soc*10)}`;const cached=memo.get(key);if(cached)return cached;let best:{score:number;path:Result[]}|null=null;for(const choice of choices){const r=runStep(s,i,soc,choice.action,choice.power,capacity);const tail=solve(i+1,r.soc);const candidate={score:objectiveValue(r,o)+tail.score,path:[r,...tail.path]};if(!best||candidate.score<best.score)best=candidate}memo.set(key,best!);return best!};return solve(0,initialSoc).path;
}
function totals(rows:Result[]){return rows.reduce((a,r)=>({cost:a.cost+r.cost,co2:a.co2+r.co2,imports:a.imports+Math.max(0,r.grid),curtailed:a.curtailed+r.curtailed}),{cost:0,co2:0,imports:0,curtailed:0})}

export default function Home(){
  const [scenarioId,setScenarioId]=useState('sunny'),[objective,setObjective]=useState<Objective>('cost'),[pvRatio,setPvRatio]=useState(125),[batteryCapacity,setBatteryCapacity]=useState(REFERENCE_CAPACITY),[customLoad,setCustomLoad]=useState<number[]|null>(null);
  const [step,setStep]=useState(0),[soc,setSoc]=useState(REFERENCE_CAPACITY*INITIAL_SOC_RATIO),[action,setAction]=useState<Action>('idle'),[power,setPower]=useState(15);
  const [results,setResults]=useState<Result[]>([]),[forecast,setForecast]=useState(false),[showPlan,setShowPlan]=useState(false);
  const baseScenario=SCENARIOS[scenarioId],s=useMemo(()=>({...baseScenario,load:customLoad??baseScenario.load,pv:baseScenario.pv.map(v=>v*pvRatio/100),forecast:baseScenario.forecast.map(v=>v*pvRatio/100)}),[scenarioId,pvRatio,customLoad]),complete=step>=HOURS.length;
  const minSoc=batteryCapacity*MIN_SOC_RATIO,initialSoc=batteryCapacity*INITIAL_SOC_RATIO;
  const plan=useMemo(()=>optimalPlan(s,objective,batteryCapacity),[s,objective,batteryCapacity]),score=useMemo(()=>totals(results),[results]),best=useMemo(()=>totals(plan),[plan]);
  const reset=(nextScenario=scenarioId)=>{if(nextScenario!==scenarioId)setCustomLoad(null);setScenarioId(nextScenario);setStep(0);setSoc(initialSoc);setAction('idle');setPower(15);setResults([]);setForecast(false);setShowPlan(false)};
  const changePvRatio=(nextRatio:number)=>{setPvRatio(nextRatio);setStep(0);setSoc(initialSoc);setAction('idle');setPower(15);setResults([]);setForecast(false);setShowPlan(false)};
  const changeBatteryCapacity=(nextCapacity:number)=>{setBatteryCapacity(nextCapacity);setStep(0);setSoc(nextCapacity*INITIAL_SOC_RATIO);setAction('idle');setPower(15);setResults([]);setForecast(false);setShowPlan(false)};
  const commit=()=>{if(complete)return;const r=runStep(s,step,soc,action,power,batteryCapacity);setResults(v=>[...v,r]);setSoc(r.soc);setStep(v=>v+1);setAction('idle')};
  const undo=()=>{if(!results.length)return;const previous=results.slice(0,-1);setResults(previous);setStep(previous.length);setSoc(previous.length?previous[previous.length-1].soc:initialSoc);setAction('idle')};
  const i=Math.min(step,HOURS.length-1),net=complete?0:s.load[step]-s.pv[step];
  const delta=action==='charge'?-Math.min(power,(batteryCapacity-soc)/EFF):action==='discharge'?Math.min(power,(soc-minSoc)*EFF):0;
  useEffect(()=>{const c=(document as Document&{modelContext?:{registerTool:(t:unknown,o?:{signal?:AbortSignal})=>void|Promise<void>}}).modelContext;if(!c?.registerTool)return;const lifecycle=new AbortController();void Promise.resolve(c.registerTool({name:'choose_battery_action',title:'Choisir l’action de la batterie',description:'Valide une action et sa puissance pour l’heure courante.',inputSchema:{type:'object',properties:{action:{type:'string',enum:['charge','idle','discharge']},powerKW:{type:'number',minimum:0,maximum:25}},required:['action','powerKW'],additionalProperties:false},annotations:{readOnlyHint:false,untrustedContentHint:false},execute:(input:unknown)=>{const x=input as {action?:Action;powerKW?:number},value=x?.action;if(!value||!['charge','idle','discharge'].includes(value)||complete||typeof x.powerKW!=='number')throw new Error('Action invalide');const r=runStep(s,step,soc,value,x.powerKW,batteryCapacity);setResults(v=>[...v,r]);setSoc(r.soc);setStep(v=>v+1);return {hour:r.hour,action:value,powerKW:Math.abs(r.batteryPower),soc:r.soc,grid:r.grid}}},{signal:lifecycle.signal})).catch(()=>undefined);return()=>lifecycle.abort()},[batteryCapacity,complete,s,step,soc]);
  return <main className="min-h-screen bg-[#f4f1e9] text-[#17342d]">
    <header className="border-b border-[#17342d]/10 bg-[#f8f6f0]/95 px-5 py-4 md:px-10"><div className="mx-auto flex max-w-[1500px] items-center justify-between gap-3"><div className="flex items-center gap-3"><img src="/logo-e4c-noir.png" alt="E4C – Institut Polytechnique de Paris" className="h-10 w-auto max-w-[110px] object-contain"/><img src="/logo-sifasol.png" alt="Sifasol" className="h-9 w-auto max-w-[80px] object-contain"/><div><p className="text-xs font-bold uppercase tracking-[.18em] text-[#557069]">Simulation EMS</p><p className="font-semibold">Jeu de gestion de batterie</p></div></div><div className="flex items-center gap-2"><a href="/documentation" className="flex items-center gap-2 rounded-xl border border-[#17342d]/15 px-3 py-2 text-sm font-semibold hover:bg-[#e8eee9]"><BookOpen size={16}/>Mode d’emploi</a><a href="/quiz" className="rounded-xl border border-[#17342d]/15 px-3 py-2 text-sm font-semibold hover:bg-[#e8eee9]">Quiz</a><button onClick={()=>reset()} className="rounded-xl bg-[#17342d] px-3 py-2 text-sm font-bold text-white">Recommencer</button></div></div></header>
    <div className="mx-auto grid max-w-[1500px] gap-5 px-4 py-5 lg:grid-cols-[minmax(0,1fr)_390px] lg:px-8">
      <section className="space-y-5">
        <div className="flex flex-col gap-5 rounded-[28px] bg-[#17342d] p-6 text-white md:flex-row md:items-end md:justify-between md:p-8"><div><p className="mb-2 text-xs font-bold uppercase tracking-[.2em] text-[#f3c969]">Votre mission</p><h1 className="text-3xl font-semibold md:text-4xl">Pilotez la batterie, heure par heure.</h1><p className="mt-3 text-sm text-white/70">Le futur réel est inconnu. Appuyez-vous sur les prévisions et les signaux réseau.</p></div><div className="grid min-w-[310px] grid-cols-2 gap-3"><Select label="Type de journée" value={scenarioId} onChange={v=>reset(v)} options={Object.entries(SCENARIOS).map(([v,x])=>[v,x.name])}/><Select label="Objectif du corrigé EMS" value={objective} onChange={v=>{setObjective(v as Objective);setShowPlan(false)}} options={Object.entries(OBJECTIVES)}/><label className="col-span-2 text-xs font-semibold uppercase tracking-wider text-white/60">Puissance PV installée <span className="float-right text-[#f3c969]">{fmt(PV_REFERENCE_KWP*pvRatio/100)} kWc · {(pvRatio/100).toFixed(2)}×</span><input aria-label="Puissance photovoltaïque installée" className="mt-3 w-full accent-[#f3c969]" type="range" min="75" max="150" step="5" value={pvRatio} onChange={e=>changePvRatio(Number(e.target.value))}/></label><label className="col-span-2 text-xs font-semibold uppercase tracking-wider text-white/60">Capacité batterie installée <span className="float-right text-[#f3c969]">{fmt(batteryCapacity,0)} kWh</span><input aria-label="Capacité batterie installée" className="mt-3 w-full accent-[#70bda5]" type="range" min="40" max="160" step="10" value={batteryCapacity} onChange={e=>changeBatteryCapacity(Number(e.target.value))}/><span className="mt-1 block normal-case tracking-normal text-white/55">Réserve {fmt(minSoc,0)} kWh · SOC initial {fmt(initialSoc,0)} kWh</span></label></div></div>
        <AutomaticPilot scenario={s} capacity={batteryCapacity}/>
        <div className="grid gap-5 xl:grid-cols-[minmax(0,1.45fr)_minmax(290px,.55fr)]">
          <article className="card p-5 md:p-6"><div className="mb-4 flex flex-wrap items-center justify-between gap-3"><div><p className="eyebrow">Énergie</p><h2 className="mt-1 text-xl font-semibold">{complete?'Journée terminée':`${HOURS[i]}h00 · ${s.subtitle}`}</h2><p className="mt-1 text-xs font-semibold text-[#526963]">Énergie du profil : {fmt(s.load.reduce((sum,value)=>sum+value,0),0)} kWh / 24 h</p></div><button onClick={()=>setForecast(v=>!v)} className={`forecast-button ${forecast?'on':''}`}><CloudSun size={17}/>{forecast?'Prévision EMS activée':'Activer la prévision'}</button></div>
            {step===0&&<LoadProfileImport templateLoad={baseScenario.load} modified={!!customLoad} onChange={setCustomLoad} onRestore={()=>setCustomLoad(null)}/>}<EnergyChart scenario={s} step={step} forecast={forecast} results={results}/>
            <div className="mt-5 flex flex-wrap gap-4 text-xs font-medium text-[#526963]"><Legend color="#17342d" text="Charge prévue"/><Legend color="#e89a45" text="PV observé"/>{forecast&&<Legend dashed text="Prévision PV"/>}<span className="ml-auto font-semibold text-[#9a5b2c]">Le PV réel futur est masqué.</span></div>
            {forecast&&<div className="mt-4 flex gap-3 rounded-xl border border-[#e2c26c] bg-[#fff3d1] px-4 py-3 text-sm text-[#755a18]"><CloudSun className="shrink-0" size={18}/><p><strong>Bulletin de 8h :</strong> {s.weather}</p></div>}
          </article>
          <aside className="card p-5 md:p-6"><div className="mb-5 flex items-center justify-between"><div><p className="eyebrow">État du système</p><h2 className="mt-1 text-xl font-semibold">Flux instantanés</h2></div><Gauge size={24}/></div><div className="energy-stack"><Flow icon={<Sun/>} label="Solaire" value={complete?'—':`${fmt(s.pv[step])} kW`} color="#e89a45"/><Flow icon={<Building2/>} label="Bâtiment" value={complete?'—':`${fmt(s.load[step])} kW`} color="#17342d"/><Flow icon={<BatteryMedium/>} label="Batterie" value={`${Math.round(soc/batteryCapacity*100)} %`} color="#4b7669"/><Flow icon={<Grid3X3/>} label="Réseau" value={complete?'—':`${fmt(net-delta)} kW`} color="#8b6d96"/></div><div className="mt-6 rounded-2xl bg-[#e8eee9] p-4"><div className="flex justify-between text-xs font-semibold"><span>Énergie stockée</span><span>{fmt(soc)} / {fmt(batteryCapacity,0)} kWh</span></div><div className="mt-2 h-3 overflow-hidden rounded-full bg-white"><div className="h-full rounded-full bg-[#4b7669] transition-all" style={{width:`${soc/batteryCapacity*100}%`}}/></div><p className="mt-2 text-xs text-[#63766f]">Réserve : {fmt(minSoc,0)} kWh · Puissance max : {MAX_POWER} kW</p></div></aside>
        </div>
        <article className="card p-5 md:p-6"><div className="flex flex-col gap-5"><div className="flex flex-col gap-5 md:flex-row md:items-end md:justify-between"><div><p className="eyebrow">Votre décision</p><h2 className="mt-1 text-xl font-semibold">Que doit faire la batterie ?</h2></div><div className="grid flex-1 gap-2 sm:grid-cols-3 md:max-w-2xl">{(['charge','idle','discharge'] as Action[]).map(a=><button key={a} disabled={complete} onClick={()=>setAction(a)} className={`decision ${action===a?'selected':''}`}><span>{a==='charge'?'↓':a==='idle'?'Ⅱ':'↑'}</span>{LABELS[a]}</button>)}</div><div className="flex gap-2"><button disabled={!results.length} onClick={undo} className="rounded-xl border border-[#17342d]/15 px-3 py-2 text-sm font-bold disabled:cursor-not-allowed disabled:opacity-35">← Revenir</button><button disabled={complete} onClick={commit} className="validate">Valider l’heure →</button></div></div>{!complete&&action!=='idle'&&<div className="power-control"><div><p className="text-sm font-bold">Puissance de {action==='charge'?'charge':'décharge'}</p><p className="text-xs text-[#63766f]">Consigne sur une heure, limitée par le SOC et les 25 kW de l’onduleur.</p></div><input aria-label="Puissance de la batterie" type="range" min="5" max="25" step="5" value={power} onChange={e=>setPower(Number(e.target.value))}/><output>{power} kW</output></div>}</div>{!complete&&<p className="mt-4 rounded-xl bg-[#fff3d1] px-4 py-3 text-sm text-[#755a18]">À {HOURS[i]}h : <strong>{fmt(s.price[i],2)} €/kWh</strong> · <strong>{s.carbon[i]} gCO₂/kWh</strong>. {action!=='idle'&&<>Consigne effective : <strong>{fmt(Math.abs(delta))} kW</strong>.</>}</p>}</article>
        {complete&&<><Debrief scenario={s} plan={plan} results={results} objective={objective} show={showPlan} setShow={setShowPlan}/><Feedback results={results} plan={plan} objective={objective}/><ClassicComparison scenario={s} capacity={batteryCapacity} optimum={plan}/></>}
      </section>
      <aside className="space-y-5"><Dashboard score={score} step={step} reset={()=>reset()}/><NetworkSignals scenario={s} step={step}/>{!complete&&<section className="card p-6"><div className="flex items-center gap-2 text-[#3f6a5d]"><Lightbulb size={19}/><p className="eyebrow">Question d’équipe</p></div><p className="mt-3 text-lg font-semibold">Faut-il utiliser l’énergie maintenant, ou la réserver pour une période plus chère et plus carbonée ?</p></section>}</aside>
    </div>
  </main>
}

function LoadProfileImport({templateLoad,modified,onChange,onRestore}:{templateLoad:number[];modified:boolean;onChange:(next:number[])=>void;onRestore:()=>void}){const [message,setMessage]=useState('');const template=`data:text/plain;charset=utf-8,${encodeURIComponent(templateLoad.join('\n'))}`;const readFile=async(event:React.ChangeEvent<HTMLInputElement>)=>{const file=event.target.files?.[0];if(!file)return;const values=(await file.text()).trim().split(/[;,\s]+/).filter(Boolean).map(Number);if(values.length!==24||values.some(value=>!Number.isFinite(value)||value<0)){setMessage('Format non valide : le fichier doit contenir exactement 24 valeurs numériques positives ou nulles.');return}onChange(values);setMessage(`Profil importé : 24 valeurs, de ${fmt(Math.min(...values),0)} à ${fmt(Math.max(...values),0)} kW.`)};return <div className="mb-4 flex flex-wrap items-center justify-between gap-2 rounded-xl border border-[#e2c26c] bg-[#fff3d1] px-3 py-2"><p title="Fichier .csv ou .txt de 24 valeurs en kW, séparées par une ligne, une virgule, un point-virgule ou un espace (de 0 h à 23 h)." className="text-xs font-semibold text-[#755a18]">Profil de consommation <span className="font-normal">· 24 valeurs kW</span></p><div className="flex shrink-0 flex-wrap gap-2"><a href={template} download="consumption-profile-24h.txt" className="rounded-lg border border-[#9a5b2c]/30 px-2.5 py-1.5 text-xs font-bold text-[#755a18]">Modèle</a><label className="cursor-pointer rounded-lg bg-[#9a5b2c] px-2.5 py-1.5 text-xs font-bold text-white">Importer<input type="file" accept=".csv,.txt,text/csv,text/plain" className="sr-only" onChange={readFile}/></label><button type="button" onClick={onRestore} disabled={!modified} className="rounded-lg border border-[#9a5b2c]/30 px-2.5 py-1.5 text-xs font-bold text-[#755a18] disabled:cursor-not-allowed disabled:opacity-40">Réinitialiser</button></div>{message&&<p className={`basis-full rounded-lg px-2 py-1 text-xs ${message.startsWith('Format')?'bg-[#fff0ec] text-[#9a3f32]':'bg-white text-[#3f6a5d]'}`}>{message}</p>}</div>}
function EnergyChart({scenario:s,step,forecast,results}:{scenario:Scenario;step:number;forecast:boolean;results:Result[]}){const done=step>=HOURS.length,count=done?HOURS.length:step+1,x=(n:number)=>n/(HOURS.length-1)*660,y=(v:number)=>205-v*2.75;const futureStart=x(Math.min(step+1,HOURS.length-1));return <div className="chart-wrap"><div className="chart-y"><span>70 kW</span><span>45</span><span>20</span><span>0</span></div><div className="chart-stage"><div className="grid-lines"><i/><i/><i/><i/></div><svg viewBox="0 0 660 220" preserveAspectRatio="none">{!done&&<rect x={futureStart} y="5" width={660-futureStart} height="205" className="future-zone"/>}<polyline className="line load-line" points={s.load.map((v,i)=>`${x(i)},${y(v)}`).join(' ')}/>{forecast&&<polyline className="line forecast-line" points={s.forecast.map((v,i)=>`${x(i)},${y(v)}`).join(' ')}/>}<polyline className="line pv-line" points={s.pv.slice(0,count).map((v,i)=>`${x(i)},${y(v)}`).join(' ')}/>{s.pv.slice(0,count).map((v,i)=><circle key={i} cx={x(i)} cy={y(v)} r="4" className="pv-dot"/>)}{results.map((r,i)=>{const bar=Math.abs(r.batteryPower)*2.75,base=205;return <g key={`decision-${i}`}><rect x={x(i)-7} y={r.batteryPower>=0?base-bar:base} width="14" height={bar} rx="3" className={r.batteryPower>=0?'decision-discharge':'decision-charge'}/><title>{`${r.hour}h : ${LABELS[r.action]} ${fmt(Math.abs(r.batteryPower))} kW`}</title></g>})}<line x1={x(Math.min(step,HOURS.length-1))} x2={x(Math.min(step,HOURS.length-1))} y1="10" y2="210" className="now-line"/></svg><div className="hour-axis" style={{gridTemplateColumns:`repeat(${HOURS.length},minmax(0,1fr))`}}>{HOURS.map((h,i)=><span key={h} className={i===step?'active':''}>{h}h</span>)}</div></div></div>}
function Select({label,value,onChange,options}:{label:string;value:string;onChange:(v:string)=>void;options:[string,string][]}){return <label className="text-xs font-semibold uppercase tracking-wider text-white/60">{label}<select value={value} onChange={e=>onChange(e.target.value)} className="mt-2 w-full rounded-xl border border-white/15 bg-white/10 px-3 py-2.5 text-sm normal-case text-white outline-none">{options.map(([v,l])=><option className="text-black" key={v} value={v}>{l}</option>)}</select></label>}
function Dashboard({score,step,reset}:{score:ReturnType<typeof totals>;step:number;reset:()=>void}){return <section className="rounded-[24px] bg-[#f3c969] p-6"><div className="flex justify-between"><div><p className="eyebrow">Tableau de bord</p><h2 className="mt-1 text-2xl font-semibold">Votre journée</h2></div><button onClick={reset} aria-label="Recommencer" className="h-9 rounded-full bg-white/45 p-2"><RotateCcw size={18}/></button></div><div className="mt-6 grid grid-cols-2 gap-3"><Metric label="Coût net" value={`${fmt(score.cost,2)} €`}/><Metric label="Émissions" value={`${fmt(score.co2/1000,2)} kg`}/><Metric label="Import réseau" value={`${fmt(score.imports)} kWh`}/><Metric label="PV exporté" value={`${fmt(score.curtailed)} kWh`}/></div><div className="mt-5 h-2 rounded-full bg-white/40"><div className="h-full rounded-full bg-[#17342d]" style={{width:`${step/HOURS.length*100}%`}}/></div><p className="mt-2 text-right text-xs font-bold">{step} / {HOURS.length} h</p></section>}
function NetworkSignals({scenario:s,step}:{scenario:Scenario;step:number}){const i=Math.min(step,HOURS.length-1);return <section className="card p-6"><p className="eyebrow">Signaux connus à l’avance</p><h2 className="mt-1 text-xl font-semibold">Réseau sur 24 h</h2><p className="mt-2 text-xs text-[#65766f]">Profils publiés la veille. Survolez une barre pour sa valeur.</p><Signal label="Prix d’achat" unit="€/kWh" values={s.price} current={i} color="#8b6d96" format={v=>fmt(v,2)}/><Signal label="Intensité carbone" unit="gCO₂/kWh" values={s.carbon} current={i} color="#e76f51" format={v=>String(v)}/><div className="mt-2 grid text-[8px] text-[#71807b]" style={{gridTemplateColumns:`repeat(${HOURS.length},minmax(0,1fr))`}}>{HOURS.map((h,n)=><span key={h} className={`text-center ${n===i?'font-bold text-[#17342d]':''}`}>{h}</span>)}</div></section>}
function Signal({label,unit,values,current,color,format}:{label:string;unit:string;values:number[];current:number;color:string;format:(v:number)=>string}){const max=Math.max(...values);return <div className="mt-5"><div className="mb-2 flex justify-between"><span className="text-xs font-semibold">{label}</span><strong style={{color}}>{format(values[current])} {unit}</strong></div><div className="signal-bars" style={{gridTemplateColumns:`repeat(${HOURS.length},minmax(0,1fr))`}}>{values.map((v,i)=><span key={i} className={i===current?'current':''} style={{height:`${Math.max(10,v/max*100)}%`,background:color}} title={`${HOURS[i]}h : ${format(v)} ${unit}`}/>)}</div></div>}
function Debrief({scenario,plan,results,objective,show,setShow}:{scenario:Scenario;plan:Result[];results:Result[];objective:Objective;show:boolean;setShow:(v:boolean)=>void}){const mine=totals(results),best=totals(plan);return <article className="rounded-[24px] bg-[#17342d] p-6 text-white md:p-8"><div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between"><div><p className="eyebrow text-[#f3c969]">Débrief · {OBJECTIVES[objective]}</p><h2 className="mt-1 text-2xl font-semibold">Votre stratégie face à l’optimum</h2><p className="mt-2 text-sm text-white/65">Le corrigé optimise aussi la puissance, par pas de 5 kW, et valorise l’énergie restante.</p></div><button onClick={()=>setShow(!show)} className="flex items-center justify-center gap-2 rounded-xl bg-[#f3c969] px-5 py-3 font-bold text-[#17342d]"><Eye size={18}/>{show?'Masquer le corrigé':'Afficher les meilleures décisions'}</button></div><div className="mt-6 grid gap-3 sm:grid-cols-3"><Compare label="Coût" you={`${fmt(mine.cost,2)} €`} best={`${fmt(best.cost,2)} €`}/><Compare label="CO₂" you={`${fmt(mine.co2/1000,2)} kg`} best={`${fmt(best.co2/1000,2)} kg`}/><Compare label="Import" you={`${fmt(mine.imports)} kWh`} best={`${fmt(best.imports)} kWh`}/></div>{show&&<><OptimalChart plan={plan} results={results}/><div className="mt-6 overflow-x-auto rounded-2xl border border-white/10"><table className="w-full min-w-[800px] text-left text-sm"><thead className="bg-white/10 text-xs uppercase text-white/60"><tr><th>Heure</th><th>Décision optimale</th><th>Puissance</th><th>SOC après</th><th>PV prévu / réel</th><th>Prix</th><th>CO₂ réseau</th></tr></thead><tbody>{plan.map((r,i)=><tr key={r.hour} className="border-t border-white/10"><td>{r.hour}h</td><td><strong className="text-[#f3c969]">{LABELS[r.action]}</strong></td><td>{r.action==='idle'?'—':`${fmt(Math.abs(r.batteryPower))} kW`}</td><td>{fmt(r.soc)} kWh</td><td>{fmt(scenario.forecast[i])} / {fmt(r.pv)} kW</td><td>{fmt(scenario.price[i],2)} €/kWh</td><td>{scenario.carbon[i]} g/kWh</td></tr>)}</tbody></table><p className="p-4 text-xs text-white/55">Cette borne idéale utilise le PV réel après coup ; un EMS réel travaille avec la prévision et son incertitude.</p></div></>}</article>}
function OptimalChart({plan,results}:{plan:Result[];results:Result[]}){const x=(i:number)=>i/(HOURS.length-1)*660,y=(v:number)=>205-v*2.75,maxSoc=Math.max(...plan.map(r=>r.soc),...results.map(r=>r.soc),1),socY=(soc:number)=>105-soc/maxSoc*82,planSoc=plan.map((r,i)=>`${x(i)},${socY(r.soc)}`).join(' ');return <div className="mt-6 rounded-2xl bg-[#fbfaf6] p-5 text-[#17342d]"><p className="eyebrow">Même lecture que pendant le jeu</p><h3 className="mt-1 text-lg font-semibold">Vos choix et ceux de l’EMS sur la journée</h3><div className="mt-4 flex flex-wrap gap-4 text-xs text-[#526963]"><Legend color="#17342d" text="Consommation"/><Legend color="#e89a45" text="PV réel"/><Legend color="#4b7669" text="Vos décisions"/><Legend color="#8b6d96" text="Contour : optimum"/></div><div className="chart-wrap mt-3"><div className="chart-y"><span>70 kW</span><span>45</span><span>20</span><span>0</span></div><div className="chart-stage"><div className="grid-lines"><i/><i/><i/><i/></div><svg viewBox="0 0 660 220" preserveAspectRatio="none" aria-label="Courbes du jeu et comparaison des décisions"><polyline className="line load-line" points={plan.map((r,i)=>`${x(i)},${y(r.load)}`).join(' ')}/><polyline className="line pv-line" points={plan.map((r,i)=>`${x(i)},${y(r.pv)}`).join(' ')}/>{results.map((r,i)=>{const h=Math.abs(r.batteryPower)*2.75,base=205,top=r.batteryPower>=0?base-h:base;return <rect key={`you-${i}`} x={x(i)-7} y={top} width="14" height={h} rx="3" className={r.batteryPower>=0?'decision-discharge':'decision-charge'}/>})}{plan.map((r,i)=>{const h=Math.abs(r.batteryPower)*2.75,base=205,top=r.batteryPower>=0?base-h:base;return <rect key={`best-${i}`} x={x(i)-8} y={top-1} width="16" height={h+2} rx="3" fill="none" stroke="#8b6d96" strokeWidth="2" strokeDasharray="4 3"/>})}</svg><div className="hour-axis" style={{gridTemplateColumns:`repeat(${HOURS.length},minmax(0,1fr))`}}>{HOURS.map(h=><span key={h}>{h}h</span>)}</div></div></div><div className="mt-7"><div className="flex flex-wrap gap-4 text-xs text-[#526963]"><Legend color="#8b6d96" text="SOC optimum (pointillé)"/><Legend color="#e89a45" text="SOC joué : charge"/><Legend color="#4b7669" text="SOC joué : décharge"/></div><p className="mt-2 text-sm font-semibold">État de charge : optimum contre votre trajectoire</p><svg viewBox="0 0 660 120" preserveAspectRatio="none" className="mt-2 h-28 w-full" aria-label="Comparaison des états de charge"><line x1="0" x2="660" y1="108" y2="108" stroke="rgba(23,52,45,.2)"/><polyline points={planSoc} fill="none" stroke="#8b6d96" strokeWidth="3" strokeDasharray="7 5" vectorEffect="non-scaling-stroke"/>{results.slice(1).map((r,i)=>{const previous=results[i],color=r.action==='charge'?'#e89a45':r.action==='discharge'?'#4b7669':'#71807b';return <line key={`soc-${i}`} x1={x(i)} y1={socY(previous.soc)} x2={x(i+1)} y2={socY(r.soc)} stroke={color} strokeWidth="4" strokeLinecap="round" vectorEffect="non-scaling-stroke"/>})}</svg></div><p className="mt-3 text-xs text-[#63766f]">Les barres pleines sont vos décisions ; le contour violet indique la consigne optimale. Le SOC joué devient orange pendant une charge et vert pendant une décharge.</p></div>}
function Flow({icon,label,value,color}:{icon:React.ReactNode;label:string;value:string;color:string}){return <div className="flow-row"><span className="flow-icon" style={{background:color}}>{icon}</span><span><small>{label}</small><strong>{value}</strong></span></div>}
function Metric({label,value}:{label:string;value:string}){return <div className="rounded-2xl bg-white/42 p-3"><p className="text-xs opacity-70">{label}</p><p className="mt-1 text-xl font-bold">{value}</p></div>}
function Compare({label,you,best}:{label:string;you:string;best:string}){return <div className="rounded-xl bg-white/7 p-4"><p className="text-xs text-white/50">{label}</p><p className="mt-1">Vous <strong>{you}</strong></p><p className="text-[#f3c969]">Optimum <strong>{best}</strong></p></div>}
function Feedback({results,plan,objective}:{results:Result[];plan:Result[];objective:Objective}){const mine=totals(results),best=totals(plan),gap=Math.max(0,mine.cost-best.cost),messages=[gap<=Math.max(.5,best.cost*.1)?'Votre coût est proche de la référence : vos arbitrages ont bien tenu compte des périodes coûteuses.':`Votre coût dépasse la référence de ${fmt(gap,2)} €. Repérez les heures où la batterie pouvait remplacer un import cher.`,mine.imports>best.imports+5?`Vous avez importé ${fmt(mine.imports-best.imports)} kWh de plus que la référence. Dans un bâtiment réel, une réserve trop faible avant une pointe peut accroître la facture et la puissance appelée.`:'Vos imports sont proches de la référence : la batterie a été mobilisée aux moments utiles.',mine.curtailed>best.curtailed+5?'Une partie importante du solaire a été exportée. Une charge pendant le surplus, ou un stockage légèrement plus grand, peut valoriser davantage cette production locale.':'Vous avez bien valorisé la production solaire locale et limité les exports évitables.'];return <article className="card border-[#e2c26c] bg-[#fffaf0] p-6 md:p-8"><p className="eyebrow text-[#9a5b2c]">Feedback pédagogique · {OBJECTIVES[objective]}</p><h2 className="mt-1 text-2xl font-semibold">Ce que votre journée raconte</h2><div className="mt-5 grid gap-3 md:grid-cols-3">{messages.map((message,i)=><p key={i} className="rounded-2xl bg-white p-4 text-sm leading-relaxed text-[#526963]">{message}</p>)}</div><p className="mt-5 rounded-xl bg-[#e8eee9] p-4 text-sm leading-relaxed text-[#3f5e55]"><strong>Application réelle :</strong> un EMS combine prévisions PV et consommation, tarifs, contraintes batterie et objectifs du site. L’optimum présenté ici connaît le PV réalisé après coup : il sert de référence pour discuter de la valeur — et des limites — d’un pilotage prédictif.</p><a href="/quiz" className="mt-5 inline-flex rounded-xl bg-[#17342d] px-4 py-2.5 text-sm font-bold text-white">Vérifier mes acquis avec le quiz →</a></article>}
function classicPlan(
  scenario: Scenario,
  capacity: number,
  mode: 'self' | 'peak',
  importLimit = 35,
  reserveRatio = MIN_SOC_RATIO,
) {
  let soc = capacity * INITIAL_SOC_RATIO;
  return HOURS.map(hour => {
    const net = scenario.load[hour] - scenario.pv[hour];
    const discharge = Math.max(0, net - (mode === 'self' ? 0 : importLimit));
    const action = net < 0 ? 'charge' : discharge > 0 ? 'discharge' : 'idle';
    const power = action === 'charge' ? -net : discharge;
    const result = runStep(scenario, hour, soc, action, power, capacity, reserveRatio);
    soc = result.soc;
    return result;
  });
}

function AutomaticPilot({scenario, capacity}: {scenario: Scenario; capacity: number}) {
  const [limit, setLimit] = useState(30);
  const [reserve, setReserve] = useState(10);
  const [run, setRun] = useState<{scenario: Scenario; capacity: number; limit: number; reserve: number}>();
  const current = run?.scenario === scenario && run.capacity === capacity && run.limit === limit && run.reserve === reserve;
  const rows = current ? classicPlan(scenario, capacity, 'peak', limit, reserve / 100) : [];
  const exceeds = (row: Result) => row.grid > limit + 1e-6;
  const peak = Math.max(0, ...rows.map(row => row.grid));
  const score = totals(rows);
  const baseline = rows.map(row => runStep(scenario, row.hour, capacity * INITIAL_SOC_RATIO, 'idle', 0, capacity));
  const before = totals(baseline);
  const solar = rows.reduce((sum, row) => sum + row.pv, 0);
  const consumption = rows.reduce((sum, row) => sum + row.load, 0);
  const charged = rows.reduce((sum, row) => sum + Math.max(0, -row.batteryPower), 0);
  const discharged = rows.reduce((sum, row) => sum + Math.max(0, row.batteryPower), 0);
  const beforePeak = Math.max(0, ...baseline.map(row => row.grid));

  return (
    <details className="card p-5 md:p-6">
      <summary className="cursor-pointer text-xl font-semibold">Pilotage automatique</summary>
      <p className="mt-3 text-sm text-[#526963]">
        La batterie charge sur surplus solaire et décharge lorsque l’import dépasse le plafond, dans la limite de sa puissance et de la réserve.
      </p>
      <div className="mt-5 grid gap-4 sm:grid-cols-2">
        <label className="text-sm font-semibold">
          <span>Plafond d’import</span> <output>{limit} kW</output>
          <input className="mt-2 block w-full accent-[#4b7669]" type="range" min={0} max={Math.max(80, Math.ceil(Math.max(...scenario.load)))} value={limit} onChange={event => {setLimit(Number(event.target.value)); setRun(undefined);}}/>
        </label>
        <label className="text-sm font-semibold">
          <span>Réserve batterie</span> <output>{reserve} %</output>
          <input className="mt-2 block w-full accent-[#4b7669]" type="range" min={10} max={INITIAL_SOC_RATIO * 100} value={reserve} onChange={event => {setReserve(Number(event.target.value)); setRun(undefined);}}/>
        </label>
      </div>
      <button type="button" className="validate mt-4" onClick={() => setRun({scenario, capacity, limit, reserve})}>
        Rejouer la journée
      </button>
      {current && (
        <div className="mt-5">
          <h2 className="text-xl font-semibold">Bilan du pilotage automatique · 24 h</h2>
          <div className="mt-4 grid gap-2 rounded-xl bg-[#e8eee9] p-3 sm:grid-cols-2 xl:grid-cols-4" aria-live="polite">
            <Metric label="Coût net" value={`${fmt(score.cost, 2)} €`}/>
            <Metric label="Émissions" value={`${fmt(score.co2 / 1000, 2)} kg`}/>
            <Metric label="Import réseau" value={`${fmt(score.imports)} kWh`}/>
            <Metric label="PV exporté" value={`${fmt(score.curtailed)} kWh`}/>
            <Metric label="Pointe d’import" value={`${fmt(peak)} kW`}/>
            <Metric label="Heures de dépassement" value={`${rows.filter(exceeds).length} h`}/>
            <Metric label="Autoconsommation PV" value={solar > 0 ? `${fmt((solar - score.curtailed) / solar * 100)} %` : '—'}/>
            <Metric label="Autosuffisance" value={consumption > 0 ? `${fmt((consumption - score.imports) / consumption * 100)} %` : '—'}/>
            <Metric label="Énergie chargée" value={`${fmt(charged)} kWh`}/>
            <Metric label="Énergie déchargée" value={`${fmt(discharged)} kWh`}/>
            <Metric label="SOC minimal" value={`${fmt(Math.min(capacity * INITIAL_SOC_RATIO, ...rows.map(row => row.soc)) / capacity * 100)} %`}/>
            <Metric label="SOC final" value={`${fmt(rows[rows.length - 1].soc / capacity * 100)} %`}/>
          </div>
          <p className="mt-3 text-xs text-[#526963]">Bilan sur 24 h, sans remise au SOC initial de 45 %. L’autosuffisance inclut l’énergie initialement stockée. Les énergies de charge et décharge sont mesurées côté bâtiment.</p>
          <div className="mt-5 overflow-x-auto rounded-xl border border-[#17342d]/15">
            <table className="w-full min-w-[420px] text-left text-sm">
              <caption className="p-3 text-left font-semibold">Même journée sans batterie et avec pilotage automatique</caption>
              <thead><tr><th scope="col" className="p-2">Indicateur</th><th scope="col" className="p-2">Sans batterie</th><th scope="col" className="p-2">Automatique</th></tr></thead>
              <tbody>
                {[
                  ['Coût net', `${fmt(before.cost, 2)} €`, `${fmt(score.cost, 2)} €`],
                  ['Émissions', `${fmt(before.co2 / 1000, 2)} kg`, `${fmt(score.co2 / 1000, 2)} kg`],
                  ['Import réseau', `${fmt(before.imports)} kWh`, `${fmt(score.imports)} kWh`],
                  ['PV exporté', `${fmt(before.curtailed)} kWh`, `${fmt(score.curtailed)} kWh`],
                  ['Pointe d’import', `${fmt(beforePeak)} kW`, `${fmt(peak)} kW`],
                ].map(([label, initial, automatic]) => <tr key={label} className="border-t border-[#17342d]/10"><th scope="row" className="p-2 font-medium">{label}</th><td className="p-2">{initial}</td><td className="p-2">{automatic}</td></tr>)}
              </tbody>
            </table>
          </div>
          <AutomaticCharts rows={rows} capacity={capacity} limit={limit} reserve={reserve}/>
          <details className="mt-5">
            <summary className="cursor-pointer font-semibold">Décisions et indicateurs heure par heure</summary>
          <div className="mt-4 overflow-x-auto">
            <table className="w-full min-w-[420px] text-left text-sm">
              <thead>
                <tr>
                  <th scope="col" className="p-2">Heure</th>
                  <th scope="col" className="p-2">Puissance batterie</th>
                  <th scope="col" className="p-2">Import réseau</th>
                  <th scope="col" className="p-2">Coût net</th>
                  <th scope="col" className="p-2">Émissions</th>
                  <th scope="col" className="p-2">SOC après</th>
                  <th scope="col" className="p-2">Dépassement</th>
                </tr>
              </thead>
              <tbody>
                {rows.map(row => (
                  <tr key={row.hour} className={exceeds(row) ? 'bg-[#fff3d1]' : 'border-t border-[#17342d]/10'}>
                    <th scope="row" className="p-2 font-medium">{row.hour} h</th>
                    <td className="p-2">{LABELS[row.action]} · {fmt(Math.abs(row.batteryPower))} kW</td>
                    <td className="p-2">
                      {fmt(Math.max(0, row.grid))} kW
                      <meter className="mt-1 block w-20" min={0} max={Math.max(peak, limit, 1)} value={Math.max(0, row.grid)} aria-label={`${fmt(Math.max(0, row.grid))} kW`}/>
                    </td>
                    <td className="p-2">{fmt(row.cost, 2)} €</td>
                    <td className="p-2">{fmt(row.co2 / 1000, 2)} kg</td>
                    <td className="p-2">
                      {fmt(row.soc / capacity * 100)} %
                      <meter className="mt-1 block w-20" min={0} max={100} value={row.soc / capacity * 100} aria-label={`${fmt(row.soc / capacity * 100)} %`}/>
                    </td>
                    <td className="p-2">{exceeds(row) ? `+${fmt(row.grid - limit, 2)} kW` : '—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          </details>
        </div>
      )}
    </details>
  );
}
function AutomaticCharts({rows, capacity, limit, reserve}: {rows: Result[]; capacity: number; limit: number; reserve: number}) {
  const x = (index: number) => 40 + index / 23 * 600;
  const maxPower = Math.max(1, limit, ...rows.map(row => Math.max(0, row.load - row.pv, row.grid)));
  const powerY = (power: number) => 175 - power / maxPower * 145;
  const socY = (percent: number) => 175 - percent * 1.45;
  const times = [0, 6, 12, 18, 23];
  return (
    <div className="mt-5 grid gap-4">
      <div className="rounded-xl bg-[#e8eee9] p-4">
        <h3 className="font-semibold">Puissance importée au réseau</h3>
        <div className="mt-2 flex flex-wrap gap-3 text-xs"><Legend color="#8b6d96" text="Sans batterie"/><Legend color="#17342d" text="Automatique"/><Legend color="#cf653f" text="Plafond d’import"/></div>
        <svg viewBox="0 0 660 205" className="mt-3 w-full" role="img" aria-label="Puissance importée avec et sans batterie et plafond d’import">
          <text x="2" y="20" fontSize="11">kW</text>
          {[0, maxPower / 2, maxPower].map(value => <g key={value}><line x1="40" x2="640" y1={powerY(value)} y2={powerY(value)} stroke="#cbd5cf"/><text x="2" y={powerY(value) + 4} fontSize="10">{fmt(value, 0)}</text></g>)}
          <line x1="40" x2="640" y1={powerY(limit)} y2={powerY(limit)} stroke="#cf653f" strokeWidth="2" strokeDasharray="6 4"/>
          <polyline points={rows.map((row, index) => `${x(index)},${powerY(Math.max(0, row.load - row.pv))}`).join(' ')} fill="none" stroke="#8b6d96" strokeWidth="2" strokeDasharray="5 4"/>
          <polyline points={rows.map((row, index) => `${x(index)},${powerY(Math.max(0, row.grid))}`).join(' ')} fill="none" stroke="#17342d" strokeWidth="3"/>
          {times.map(hour => <text key={hour} x={x(hour)} y="198" textAnchor="middle" fontSize="11">{hour} h</text>)}
        </svg>
      </div>
      <div className="rounded-xl bg-[#e8eee9] p-4">
        <h3 className="font-semibold">État de charge de la batterie</h3>
        <div className="mt-2 flex flex-wrap gap-3 text-xs"><Legend color="#4b7669" text="SOC automatique"/><Legend color="#cf653f" text="Réserve batterie"/></div>
        <svg viewBox="0 0 660 205" className="mt-3 w-full" role="img" aria-label="État de charge automatique et réserve sur 24 heures">
          <text x="2" y="20" fontSize="11">%</text>
          {[0, 50, 100].map(value => <g key={value}><line x1="40" x2="640" y1={socY(value)} y2={socY(value)} stroke="#cbd5cf"/><text x="2" y={socY(value) + 4} fontSize="10">{value}</text></g>)}
          <line x1="40" x2="640" y1={socY(reserve)} y2={socY(reserve)} stroke="#cf653f" strokeWidth="2" strokeDasharray="6 4"/>
          <polyline points={[`40,${socY(INITIAL_SOC_RATIO * 100)}`, ...rows.map(row => `${40 + (row.hour + 1) / 24 * 600},${socY(row.soc / capacity * 100)}`)].join(' ')} fill="none" stroke="#4b7669" strokeWidth="3"/>
          {[0, 6, 12, 18, 24].map(hour => <text key={hour} x={40 + hour / 24 * 600} y="198" textAnchor="middle" fontSize="11">{hour} h</text>)}
        </svg>
      </div>
    </div>
  );
}
function normalisedTotals(rows:Result[],capacity:number){const raw=totals(rows),target=capacity*INITIAL_SOC_RATIO,finalSoc=rows.at(-1)?.soc??target,recharge=Math.max(0,target-finalSoc);return {cost:raw.cost+recharge*.18,co2:raw.co2+recharge*55,imports:raw.imports+recharge,recharge,finalSoc}}
function ClassicComparison({scenario,capacity,optimum}:{scenario:Scenario;capacity:number;optimum:Result[]}){const [show,setShow]=useState(false),self=useMemo(()=>classicPlan(scenario,capacity,'self'),[scenario,capacity]),peak=useMemo(()=>classicPlan(scenario,capacity,'peak'),[scenario,capacity]),opt=normalisedTotals(optimum,capacity);return <article className="card p-6 md:p-8"><div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between"><div><p className="eyebrow">Références terrain</p><h2 className="mt-1 text-2xl font-semibold">Et sans optimisation EMS ?</h2><p className="mt-2 text-sm text-[#526963]">Comparaison équitable : chaque stratégie est ramenée au SOC initial de 45 % avant le bilan.</p></div><button onClick={()=>setShow(v=>!v)} className="rounded-xl bg-[#17342d] px-5 py-3 text-sm font-bold text-white">{show?'Masquer la comparaison':'Afficher les stratégies classiques'}</button></div>{show&&<><div className="mt-5 rounded-xl bg-[#17342d] p-4 text-sm text-white">Référence EMS normalisée : <strong>{fmt(opt.cost,2)} €</strong> · <strong>{fmt(opt.co2/1000,1)} kg CO₂</strong> · <strong>{fmt(opt.imports,0)} kWh importés</strong></div><div className="mt-6 grid gap-4 md:grid-cols-2"><ClassicCard title="Autoconsommation simple" text="Charge seulement sur surplus PV ; décharge dès qu’il y a un besoin." rows={self} capacity={capacity}/><ClassicCard title="Écrêtage de pointe" text="Charge sur surplus PV ; décharge seulement au-delà de 35 kW d’import." rows={peak} capacity={capacity}/></div></>}</article>}
function ClassicCard({title,text,rows,capacity}:{title:string;text:string;rows:Result[];capacity:number}){const t=normalisedTotals(rows,capacity);return <div className="rounded-2xl bg-[#e8eee9] p-5"><h3 className="font-semibold">{title}</h3><p className="mt-2 text-sm text-[#526963]">{text}</p><div className="mt-4 grid grid-cols-3 gap-2 text-center text-sm"><Metric label="Coût ajusté" value={`${fmt(t.cost,2)} €`}/><Metric label="CO₂ ajusté" value={`${fmt(t.co2/1000,1)} kg`}/><Metric label="Import ajusté" value={`${fmt(t.imports,0)} kWh`}/></div><p className="mt-3 text-xs text-[#63766f]">SOC final brut : {fmt(t.finalSoc,1)} kWh · rééquilibrage compté : {fmt(t.recharge,1)} kWh.</p><ClassicChart rows={rows}/></div>}
function ClassicChart({rows}:{rows:Result[]}){const x=(i:number)=>i/(HOURS.length-1)*660,y=(v:number)=>205-v*2.75;return <div className="mt-5 rounded-xl bg-white p-3"><p className="mb-2 text-xs font-bold text-[#526963]">Courbes et décisions de la stratégie</p><svg viewBox="0 0 660 220" preserveAspectRatio="none" className="h-40 w-full" aria-label="Simulation de stratégie classique"><polyline className="line load-line" points={rows.map((r,i)=>`${x(i)},${y(r.load)}`).join(' ')}/><polyline className="line pv-line" points={rows.map((r,i)=>`${x(i)},${y(r.pv)}`).join(' ')}/>{rows.map((r,i)=>{const h=Math.abs(r.batteryPower)*2.75,base=205,top=r.batteryPower>=0?base-h:base;return <rect key={i} x={x(i)-6} y={top} width="12" height={h} rx="3" className={r.batteryPower>=0?'decision-discharge':'decision-charge'}/>})}</svg><div className="grid text-[8px] text-[#71807b]" style={{gridTemplateColumns:`repeat(${HOURS.length},minmax(0,1fr))`}}>{HOURS.map(h=><span key={h} className="text-center">{h}h</span>)}</div><p className="mt-2 text-[11px] text-[#63766f]">Noir : consommation · orange : PV · barres : batterie.</p></div>}
function Legend({color,text,dashed}:{color?:string;text:string;dashed?:boolean}){return <span className="legend"><i style={dashed?{background:'repeating-linear-gradient(90deg,#4b7669 0 5px,transparent 5px 8px)'}:{background:color}}/>{text}</span>}
