# Publication GitHub Pages

Dépôt public : https://github.com/jordibadosa-cyber/jeu-gestion-batterie

Site : https://jordibadosa-cyber.github.io/jeu-gestion-batterie/

Publication du 24 octobre 2026 : fichiers statiques à la racine de la branche `main`, GitHub Pages configuré sur `main / (root)`.

Le connecteur GitHub n’ayant pas accès au nouveau dépôt, les fichiers ont été envoyés par l’interface GitHub. Le dépôt contient une archive des sources `sources-jeu-gestion-batterie.zip` et la version compilée. Le dépôt local conserve les sources séparées et la configuration Sites existante. Le remote `github` désigne le dépôt public ; le remote `sites` est conservé.

Les modifications locales ne sont pas publiées automatiquement. Recompiler avec `node github-pages/build.mjs`, puis actualiser les fichiers statiques sur GitHub pour une nouvelle publication.
