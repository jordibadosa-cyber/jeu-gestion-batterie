import { build } from 'vite';
import { mkdir, copyFile, writeFile } from 'node:fs/promises';
await build({ configFile: new URL('./vite.config.ts', import.meta.url).pathname });
for (const path of ['documentation', 'quiz', 'en', 'en/documentation', 'en/quiz']) {
  await mkdir(new URL(`./dist/${path}/`, import.meta.url), { recursive: true });
  await copyFile(new URL('./dist/index.html', import.meta.url), new URL(`./dist/${path}/index.html`, import.meta.url));
}
await writeFile(new URL('./dist/.nojekyll', import.meta.url), '');
