import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/postcss';
import { fileURLToPath } from 'node:url';
const root = fileURLToPath(new URL('../', import.meta.url));
const base = process.env.PAGES_BASE_PATH || '/jeu-gestion-batterie/';
const prefix = base.replace(/\/$/, '');
export default defineConfig({
  root: `${root}github-pages`, base,
  publicDir: `${root}public`,
  resolve: { alias: { '@': root } },
  css: { postcss: { plugins: [tailwindcss()] } },
  plugins: [{
    name: 'github-pages-paths', enforce: 'pre',
    transform(code, id) {
      if (!id.startsWith(root) || id.includes('node_modules')) return;
      if (/\/app\/.*\.tsx$/.test(id)) code = code.replace(/(href|src)="\/(?!\/)([^"]*)"/g, (_, attr, path) => `${attr}="${base}${path}${attr === 'href' && path && !path.endsWith('/') ? '/' : ''}"`);
      if (id.endsWith('/components/LanguageSwitcher.tsx')) {
        code = code.replaceAll('window.location.pathname', `(window.location.pathname.slice(${prefix.length}).replace(/\\/$/, '') || '/')`);
        code = code.replace(/link\.href = .*?;/, `const current = window.location.pathname.slice(${prefix.length}).replace(/\\/$/, '') || '/'; link.href = ${JSON.stringify(prefix)} + (english ? current.replace(/^\\/en/, '') || '/' : '/en' + (current === '/' ? '/' : current + '/'));`);
      }
      if (id.endsWith('/lib/english.ts')) {
        code = code.replace("const href = link.getAttribute('href') ?? '';", `const raw = link.getAttribute('href') ?? ''; const href = raw.startsWith(${JSON.stringify(base)}) ? raw.slice(${prefix.length}) : raw;`);
        code = code.replace('link.href = `/en${href ===', `link.href = ${JSON.stringify(prefix)} + \`/en\${href ===`);
      }
      return code;
    },
  }, react()],
  build: { outDir: `${root}github-pages/dist`, emptyOutDir: true },
});
