# GitHub Pages

Depuis la racine du projet : `node github-pages/build.mjs`.

Publier le contenu de `github-pages/dist` sur GitHub Pages. Les six routes françaises et anglaises sont générées avec leurs propres fichiers index.html.

Le chemin par défaut est `/jeu-gestion-batterie/`. Pour un autre nom de dépôt, définir `PAGES_BASE_PATH=/nom-du-depot/` avant la compilation.

Cette configuration réutilise les composants et le modèle du jeu sans modifier la version Sites. Elle adapte les liens, les images et le changement de langue au sous-dossier GitHub Pages.
