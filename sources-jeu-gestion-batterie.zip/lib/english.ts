'use client';

import { useEffect } from 'react';

// The game is intentionally authored once.  This small presentation layer keeps
// the French and English routes functionally identical: calculations, charts and
// scoring always use the same model.
const translations: Record<string, string> = {
  'Jeu de gestion de batterie': 'Battery Management Game',
  'Simulation EMS': 'EMS simulation',
  'Mode d’emploi': 'How to play',
  'Retour au jeu': 'Back to the game',
  'Recommencer': 'Restart',
  'Quiz': 'Quiz',
  'Votre mission': 'Your mission',
  'Pilotez la batterie, heure par heure.': 'Operate the battery, hour by hour.',
  'Le futur réel est inconnu. Appuyez-vous sur les prévisions et les signaux réseau.': 'Future actual conditions are unknown. Use forecasts and grid signals.',
  'Type de journée': 'Day type',
  'Objectif du corrigé EMS': 'EMS reference objective',
  'Puissance PV installée': 'Installed PV capacity',
  'Capacité batterie installée': 'Installed battery capacity',
  'Réserve': 'Reserve', 'SOC initial': 'Initial SOC',
  'Journée variable': 'Variable day', 'Journée ensoleillée': 'Sunny day', "Journée d’hiver": 'Winter day',
  'Front nuageux imprévisible': 'Unpredictable cloud front', 'Surplus solaire à midi': 'Solar surplus at noon', 'PV faible, pointe marquée': 'Low PV, pronounced peak',
  'Énergie': 'Energy', 'Journée terminée': 'Day complete', 'Prévision EMS activée': 'EMS forecast enabled', 'Activer la prévision': 'Enable forecast',
  'Charge prévue': 'Building load', 'PV observé': 'Observed PV', 'Prévision PV': 'PV forecast', 'Le PV réel futur est masqué.': 'Future actual PV is hidden.',
  'État du système': 'System status', 'Flux instantanés': 'Instantaneous flows', 'Solaire': 'Solar', 'Bâtiment': 'Building', 'Batterie': 'Battery', 'Réseau': 'Grid',
  'Énergie stockée': 'Stored energy', 'Puissance max :': 'Maximum power:',
  'Bilan du pilotage automatique · 24 h': 'Automatic control results · 24 h',
  'Autoconsommation PV': 'PV self-consumption', 'Autosuffisance': 'Self-sufficiency',
  'Énergie chargée': 'Energy charged', 'Énergie déchargée': 'Energy discharged', 'SOC minimal': 'Minimum SOC',
  'Bilan sur 24 h, sans remise au SOC initial de 45 %. L’autosuffisance inclut l’énergie initialement stockée. Les énergies de charge et décharge sont mesurées côté bâtiment.': '24-hour results without restoring the initial 45% SOC. Self-sufficiency includes initially stored energy. Charging and discharging energy is measured on the building side.',
  'Même journée sans batterie et avec pilotage automatique': 'Same day without battery and with automatic control',
  'Sans batterie': 'Without battery', 'Automatique': 'Automatic', 'Indicateur': 'Indicator',
  'Puissance importée au réseau': 'Grid import power', 'État de charge de la batterie': 'Battery state of charge',
  'SOC automatique': 'Automatic SOC', 'Puissance batterie': 'Battery power',
  'Décisions et indicateurs heure par heure': 'Hourly decisions and indicators',
  'Pilotage automatique': 'Automatic control',
  'La batterie charge sur surplus solaire et décharge lorsque l’import dépasse le plafond, dans la limite de sa puissance et de la réserve.': 'The battery charges on solar surplus and discharges above the grid import limit, subject to its power rating and reserve.',
  'Plafond d’import': 'Grid import limit', 'Réserve batterie': 'Battery reserve',
  'Rejouer la journée': 'Replay the day', 'Pointe d’import': 'Peak grid import',
  'Heures de dépassement': 'Hours above the limit', 'SOC final': 'Final SOC', 'Dépassement': 'Above limit',
  'Votre décision': 'Your decision', 'Que doit faire la batterie ?': 'What should the battery do?',
  'Charger': 'Charge', 'Attendre': 'Wait', 'Décharger': 'Discharge', '← Revenir': '← Go back', 'Valider l’heure →': 'Confirm hour →',
  'Puissance de charge': 'Charging power', 'Puissance de décharge': 'Discharging power', 'Consigne sur une heure, limitée par le SOC et les 25 kW de l’onduleur.': 'One-hour setpoint, limited by SOC and the inverter’s 25 kW rating.',
  'Tableau de bord': 'Dashboard', 'Votre journée': 'Your day', 'Coût net': 'Net cost', 'Émissions': 'Emissions', 'Import réseau': 'Grid imports', 'PV exporté': 'PV exports',
  'Signaux connus à l’avance': 'Known in advance', 'Réseau sur 24 h': 'Grid over 24 hours', 'Profils publiés la veille. Survolez une barre pour sa valeur.': 'Profiles published the day before. Hover over a bar to see its value.',
  'Prix d’achat': 'Purchase price', 'Intensité carbone': 'Carbon intensity',
  'Question d’équipe': 'Team question', 'Faut-il utiliser l’énergie maintenant, ou la réserver pour une période plus chère et plus carbonée ?': 'Should the energy be used now, or kept for a more expensive and carbon-intensive period?',
  'Votre stratégie face à l’optimum': 'Your strategy compared with the optimum', 'Afficher les meilleures décisions': 'Show best decisions', 'Masquer le corrigé': 'Hide reference solution',
  'Coût': 'Cost', 'Import': 'Imports', 'Vous': 'You', 'Optimum': 'Optimum', 'Heure': 'Hour', 'Décision optimale': 'Optimal decision', 'Puissance': 'Power', 'SOC après': 'SOC after', 'PV prévu / réel': 'Forecast / actual PV', 'Prix': 'Price', 'CO₂ réseau': 'Grid CO₂',
  'Même lecture que pendant le jeu': 'Same view as during the game', 'Vos choix et ceux de l’EMS sur la journée': 'Your choices and the EMS choices over the day', 'Consommation': 'Load', 'PV réel': 'Actual PV', 'Vos décisions': 'Your decisions', 'Contour : optimum': 'Outline: optimum',
  'SOC optimum (pointillé)': 'Optimal SOC (dashed)', 'SOC joué : charge': 'Your SOC: charging', 'SOC joué : décharge': 'Your SOC: discharging', 'État de charge : optimum contre votre trajectoire': 'State of charge: optimum versus your trajectory',
  'Feedback pédagogique': 'Learning feedback', 'Ce que votre journée raconte': 'What your day reveals', 'Vérifier mes acquis avec le quiz →': 'Check my learning with the quiz →',
  'Références terrain': 'Field references', 'Et sans optimisation EMS ?': 'What happens without EMS optimisation?', 'Afficher les stratégies classiques': 'Show conventional strategies', 'Masquer la comparaison': 'Hide comparison',
  'Personnaliser la consommation': 'Customise consumption', 'Restaurer le profil': 'Restore profile',
  'Importer une courbe de consommation': 'Import a consumption curve', 'Télécharger le modèle': 'Download template', 'Sélectionner un fichier': 'Select a file',
  'Profil de consommation': 'Consumption profile', 'Modèle': 'Template', 'Importer': 'Import', 'Réinitialiser': 'Reset',
  'Autoconsommation simple': 'Simple self-consumption', 'Écrêtage de pointe': 'Peak shaving', 'Coût ajusté': 'Adjusted cost', 'CO₂ ajusté': 'Adjusted CO₂', 'Import ajusté': 'Adjusted imports', 'Courbes et décisions de la stratégie': 'Strategy curves and decisions',
  'Noir : consommation · orange : PV · barres : batterie.': 'Black: load · orange: PV · bars: battery.',
  'Exercice EMS': 'EMS exercise', 'Piloter une batterie dans un bâtiment tertiaire': 'Operating a battery in a commercial building',
  'L’objectif est de prendre des décisions réalistes sous incertitude, puis de comprendre ce que l’EMS gagne grâce aux prévisions et à l’optimisation.': 'The aim is to make realistic decisions under uncertainty, then understand what an EMS gains from forecasts and optimisation.',
  'Prévision ≠ réalité': 'Forecast ≠ reality', 'Puissance vs énergie': 'Power versus energy', 'Objectifs concurrents': 'Competing objectives',
  'Prix d’achat — €/kWh.': 'Purchase price — €/kWh.', 'Intensité carbone — gCO₂/kWh.': 'Carbon intensity — gCO₂/kWh.', 'Lecture du graphique.': 'Reading the chart.', 'Limites du modèle.': 'Model limitations.',
  'Hypothèses du modèle batterie': 'Battery-model assumptions', 'Une batterie simplifiée, mais cohérente pour l’exercice': 'A simplified battery, consistent with the exercise', 'Énergie et puissance.': 'Energy and power.', 'Rendement.': 'Efficiency.', 'Granularité.': 'Granularity.', 'Simplifications.': 'Simplifications.',
  'Suggestion d’animation :': 'Facilitation suggestion:',
  'Quiz d’arbitrage': 'Decision-making quiz', 'Auto-évaluation progressive': 'Progressive self-assessment', 'Raisonner comme un EMS': 'Reason like an EMS', 'Chaque clic donne immédiatement la correction. Les schémas simplifiés servent à pratiquer calculs et arbitrages.': 'Each click shows the correction immediately. Simplified diagrams help you practise calculations and trade-offs.',
  'Progression :': 'Progress:', 'Bonnes réponses :': 'Correct answers:', 'Situation': 'Question', 'Bilan': 'Summary',
};

const longer: Array<[string, string]> = [
  ['1. Choisir le contexte', '1. Choose the context'],
  ['La courbe de consommation représente un bâtiment tertiaire : charge de fond la nuit, montée à l’ouverture, activité soutenue en journée et pointe en fin d’après-midi. Les trois journées font varier ce profil pour illustrer une occupation et des usages CVC différents. Ajustez ensuite la puissance PV et la capacité batterie pour discuter du dimensionnement.', 'The load curve represents a commercial building: base load at night, ramp-up at opening, sustained daytime activity and a late-afternoon peak. The three days vary this profile to illustrate different occupancy and HVAC uses. Then adjust PV capacity and battery capacity to discuss sizing.'],
  ['2. Activer la prévision (optionnel)', '2. Enable the forecast (optional)'],
  ['Le jeu démarre sans prévision solaire, comme un pilotage réactif. Cliquez sur « Activer la prévision » pour afficher la courbe PV anticipée et comparer l’avantage d’un EMS informé. Le PV réel futur demeure toujours caché.', 'The game starts without a solar forecast, like reactive control. Click “Enable forecast” to display anticipated PV and compare the advantage of an informed EMS. Future actual PV always remains hidden.'],
  ['3. Décider et doser', '3. Decide and set the power'],
  ['À chaque heure, choisissez charge, attente ou décharge, puis une puissance de 5 à 25 kW. La consigne est limitée par l’onduleur et l’état de charge.', 'At each hour, choose charge, wait or discharge, then a power between 5 and 25 kW. The setpoint is limited by the inverter and the state of charge.'],
  ['4. Débriefer équitablement', '4. Debrief fairly'],
  ['À la fin, comparez coût, émissions et imports avec l’EMS et les stratégies classiques. Pour être comparable, chaque stratégie est ramenée au SOC initial de 45 % : l’énergie de reconstitution est comptée. Le corrigé EMS teste les puissances par paliers de 5 kW ; les stratégies classiques suivent simplement leur règle de pilotage.', 'At the end, compare cost, emissions and imports with the EMS and conventional strategies. For comparability, each strategy is returned to the initial 45% SOC: replenishment energy is included. The EMS reference tests power in 5 kW increments; conventional strategies simply follow their control rule.'],
  ['La prévision fournit un avantage, pas une certitude. Observez comment un écart solaire affecte votre réserve.', 'A forecast provides an advantage, not certainty. Observe how a solar deviation affects your reserve.'],
  ['Les kW définissent la vitesse de charge/décharge ; les kWh décrivent l’énergie stockée.', 'kW define charging/discharging speed; kWh describe stored energy.'],
  ['Minimiser le coût, le CO₂ ou les imports peut conduire à des décisions différentes.', 'Minimising cost, CO₂ or imports can lead to different decisions.'],
  ['Comprendre les courbes réseau', 'Understanding grid curves'],
  ['Des signaux pour arbitrer la charge et la décharge', 'Signals for deciding when to charge and discharge'],
  ['Cette courbe représente un tarif horaire simplifié d’électricité importée : un prix bas invite plutôt à charger, un prix élevé à préserver ou décharger la batterie. Le profil est pédagogique, inspiré d’un signal de marché ou d’une tarification dynamique, et non d’une offre contractuelle réelle. Les exports PV sont valorisés à un tarif fixe de 0,06 €/kWh.', 'This curve represents a simplified hourly tariff for imported electricity: a low price can favour charging, while a high price can favour preserving or discharging the battery. It is a teaching profile inspired by a market signal or dynamic tariff, not a real contractual offer. PV exports are valued at a fixed €0.06/kWh.'],
  ['Elle représente les émissions associées à un kWh importé à chaque heure. Une valeur forte signale une période où le grid est supposé plus carboné : éviter un import à ce moment réduit les émissions calculées. Les valeurs sont des profils illustratifs cohérents pour l’exercice, pas une donnée temps réel ni un bilan de cycle de vie complet.', 'It represents emissions associated with one imported kWh at each hour. A high value signals a period in which the grid is assumed to be more carbon-intensive: avoiding an import then lowers calculated emissions. The values are illustrative profiles for the exercise, not real-time data or a full life-cycle assessment.'],
  ['Les barres couvrent les 24 heures connues à l’avance et la barre mise en évidence correspond à l’heure en cours. L’enjeu est de regarder les heures suivantes : énergie solaire anticipée, prix et CO₂ peuvent conduire à conserver une réserve plutôt qu’à agir immédiatement.', 'The bars cover the 24 hours known in advance and the highlighted bar is the current hour. Look ahead: anticipated solar energy, price and CO₂ can make keeping a reserve preferable to acting immediately.'],
  ['Le jeu comptabilise les émissions des imports réseau à l’instant considéré. Il ne suit pas encore le contenu carbone stocké dans la batterie, son empreinte de fabrication, ni les écarts réels entre prévision et signal réseau.', 'The game counts emissions from grid imports at the time they occur. It does not yet track the carbon content stored in the battery, its manufacturing footprint, or actual deviations between forecast and grid signals.'],
  ['Capacité nominale réglable de 40 à 160 kWh (80 kWh par défaut), réserve incompressible égale à 10 % de la capacité, état initial à 45 % et puissance maximale de charge ou de décharge de 25 kW.', 'Adjustable nominal capacity from 40 to 160 kWh (80 kWh by default), a minimum reserve equal to 10% of capacity, an initial state of 45%, and a maximum charging or discharging power of 25 kW.'],
  ['Le rendement est de 94 % à la charge et de 94 % à la décharge, soit environ 88 % aller-retour. Une consigne de 25 kW pendant une heure ne modifie donc pas le SOC de 25 kWh exactement.', 'Efficiency is 94% while charging and 94% while discharging, or about 88% round trip. A 25 kW setpoint for one hour therefore does not change SOC by exactly 25 kWh.'],
  ['Chaque décision vaut pour un pas d’une heure. La puissance effective peut être réduite automatiquement lorsque la batterie atteint sa réserve ou sa capacité maximale.', 'Each decision applies for a one-hour step. Effective power can be reduced automatically when the battery reaches its reserve or maximum capacity.'],
  ['L’autodécharge, le vieillissement, les pertes fixes de l’onduleur, les contraintes thermiques et les coûts d’usure ne sont pas représentés ; ils seraient importants dans une étude de dimensionnement détaillée.', 'Self-discharge, ageing, fixed inverter losses, thermal constraints and degradation costs are not represented; they would matter in a detailed sizing study.'],
  ['faites jouer un groupe sans la prévision, un autre avec. Comparez ensuite leurs courbes d’état de charge, puis changez la puissance PV installée : cela ouvre naturellement la discussion sur le surdimensionnement, le stockage et l’écrêtement.', 'have one group play without the forecast and another with it. Then compare their state-of-charge curves and change installed PV capacity: this naturally opens a discussion of oversizing, storage and curtailment.'],
  ['Elle représente les émissions associées à un kWh importé à chaque heure. Une valeur forte signale une période où le réseau est supposé plus carboné : éviter un import à ce moment réduit les émissions calculées. Les valeurs sont des profils illustratifs cohérents pour l’exercice, pas une donnée temps réel ni un bilan de cycle de vie complet.', 'It represents emissions associated with one imported kWh at each hour. A high value signals a period in which the grid is assumed to be more carbon-intensive: avoiding an import then lowers calculated emissions. The values are illustrative profiles for the exercise, not real-time data or a full life-cycle assessment.'],
  ['Une batterie délivre 20 kW pendant 2 h. Quelle énergie délivre-t-elle, avant pertes ?', 'A battery delivers 20 kW for 2 h. How much energy does it deliver, before losses?'],
  ['Avec 94 % de rendement à la charge, 20 kW chargés pendant une heure augmentent le SOC de :', 'With 94% charging efficiency, charging at 20 kW for one hour increases SOC by:'],
  ['SOC = 20 kWh, réserve = 8 kWh, rendement de décharge = 94 %. Quelle énergie maximale est délivrable ?', 'SOC = 20 kWh, reserve = 8 kWh, discharge efficiency = 94%. What is the maximum deliverable energy?'],
  ['La prévision annonce un fort surplus PV à midi. À 9 h, avec un SOC déjà haut, quelle stratégie est robuste ?', 'The forecast announces a large PV surplus at noon. At 09:00, with an already high SOC, which strategy is robust?'],
  ['À midi : PV = 60 kW, bâtiment = 30 kW, batterie charge à 20 kW. Que devient le solde ?', 'At noon: PV = 60 kW, building = 30 kW, battery charges at 20 kW. What happens to the balance?'],
  ['Pourquoi un prix élevé le soir ne signifie-t-il pas toujours « décharger » ?', 'Why does a high evening price not always mean “discharge”?'],
  ['0,10 €/kWh à 3 h, puis 0,40 €/kWh à 19 h : quel usage peut justifier une charge réseau à 3 h ?', '€0.10/kWh at 03:00, then €0.40/kWh at 19:00: what use can justify grid charging at 03:00?'],
  ['Une intensité de 120 gCO₂/kWh représente dans le jeu :', 'In the game, a carbon intensity of 120 gCO₂/kWh represents:'],
  ['Pourquoi augmenter uniquement la capacité de 80 à 160 kWh peut ne pas suffire ?', 'Why might increasing capacity alone from 80 to 160 kWh not be enough?'],
  ['Que révèle l’écart entre votre stratégie et l’optimum ?', 'What does the gap between your strategy and the optimum reveal?'],
  ['40 kWh', '40 kWh'], ['18,8 kWh', '18.8 kWh'], ['11,3 kWh', '11.3 kWh'],
  ['Garder de la place pour le surplus attendu.', 'Keep room for the expected surplus.'], ['Charger au maximum depuis le réseau.', 'Charge from the grid at maximum power.'], ['Décharger systématiquement.', 'Always discharge.'],
  ['10 kW exportés ou écrêtés.', '10 kW exported or curtailed.'], ['La batterie fournit 10 kW.', 'The battery provides 10 kW.'], ['Le réseau importe 10 kW.', 'The grid imports 10 kW.'],
  ['Il faut aussi vérifier le SOC, la pointe future, le CO₂ et les pertes.', 'You must also consider SOC, the future peak, CO₂ and losses.'], ['Le prix n’a aucun rôle.', 'Price has no role.'], ['Une batterie ne peut pas décharger le soir.', 'A battery cannot discharge in the evening.'],
  ['Préparer une décharge à 19 h si le gain couvre les pertes.', 'Prepare to discharge at 19:00 if the gain covers the losses.'], ['Éviter le solaire de midi.', 'Avoid midday solar.'], ['Annuler le rendement.', 'Cancel efficiency.'],
  ['Le contenu carbone du kWh importé à cette heure.', 'The carbon content of the kWh imported at that hour.'], ['L’empreinte de fabrication de la batterie.', 'The battery manufacturing footprint.'], ['Une puissance PV.', 'PV power.'],
  ['La puissance de l’onduleur reste limitée à 25 kW.', 'Inverter power remains limited to 25 kW.'], ['Le rendement devient 100 %.','Efficiency becomes 100%.'], ['La consommation disparaît.','Consumption disappears.'],
  ['Une opportunité de discuter des informations et contraintes manquantes.', 'An opportunity to discuss missing information and constraints.'], ['Que vos décisions n’ont aucune valeur.', 'That your decisions have no value.'], ['Que le PV réel était connu à l’avance.', 'That actual PV was known in advance.'],
  ['✓ Bonne réponse. ', '✓ Correct answer. '],
  ['Énergie = puissance × durée : 20 kW × 2 h = 40 kWh.', 'Energy = power × duration: 20 kW × 2 h = 40 kWh.'],
  ['La batterie reçoit 20 × 0,94 = 18,8 kWh.', 'The battery receives 20 × 0.94 = 18.8 kWh.'],
  ['12 kWh sont disponibles au-dessus de la réserve ; après pertes : 12 × 0,94 = 11,3 kWh.', '12 kWh are available above the reserve; after losses: 12 × 0.94 = 11.3 kWh.'],
  ['La prévision aide à préparer une marge de stockage, tout en gardant en tête son incertitude.', 'The forecast helps create storage headroom while keeping its uncertainty in mind.'],
  ['Le surplus est 30 kW ; après 20 kW de charge, il reste 10 kW.', 'The surplus is 30 kW; after 20 kW of charging, 10 kW remain.'],
  ['Un EMS arbitre plusieurs contraintes et objectifs ; il peut être pertinent de conserver une réserve.', 'An EMS balances several constraints and objectives; keeping a reserve can be sensible.'],
  ['Le décalage temporel peut être pertinent si le gain économique ou carbone compense pertes et usure.', 'Time shifting can make sense if the economic or carbon benefit offsets losses and wear.'],
  ['Le modèle suit les émissions des imports horaires ; il ne suit pas encore le contenu carbone stocké.', 'The model tracks emissions from hourly imports; it does not yet track stored carbon content.'],
  ['Capacité (kWh) et puissance (kW) sont deux leviers distincts.', 'Capacity (kWh) and power (kW) are two separate levers.'],
  ['L’optimum connaît le PV réalisé après coup : c’est une borne pédagogique, pas une consigne directement applicable.', 'The optimum knows actual PV after the fact: it is a teaching benchmark, not a directly usable setpoint.'],
  ['Très solide : vous articulez énergie, puissance, prévision et contraintes.', 'Very strong: you connect energy, power, forecasts and constraints.'],
  ['Bon niveau : reprenez les situations où pertes et limites de puissance changent la décision.', 'Good level: revisit situations where losses and power limits change the decision.'],
  ['Refaites une journée de jeu puis revenez aux schémas : les arbitrages deviendront plus intuitifs.', 'Play another day, then return to the diagrams: the trade-offs will become more intuitive.'],
  ['Ciel clair, quelques voiles élevés · incertitude ± 5 kW', 'Clear sky with high thin clouds · uncertainty ± 5 kW'],
  ['Passage nuageux probable entre 13h et 16h · incertitude ± 12 kW', 'Cloud passage likely between 13:00 and 16:00 · uncertainty ± 12 kW'],
  ['Éclaircies courtes vers midi · incertitude ± 7 kW', 'Brief clear spells around noon · uncertainty ± 7 kW'],
  ['Bulletin de 8h :', '08:00 bulletin:'],
  ['Avant de jouer, faites glisser les points noirs pour régler la consommation de chaque heure.', 'Before playing, drag the black points to set consumption at each hour.'],
  ['Choisissez un fichier .csv ou .txt contenant 24 valeurs de puissance en kW, séparées par une ligne, une virgule, un point-virgule ou un espace (de 0 h à 23 h).', 'Choose a .csv or .txt file containing 24 power values in kW, separated by a line break, comma, semicolon or space (from 00:00 to 23:00).'],
  ['Format non valide : le fichier doit contenir exactement 24 valeurs numériques positives ou nulles.', 'Invalid format: the file must contain exactly 24 non-negative numeric values.'],
  ['À ', 'At '],
  ['Consigne effective :', 'Effective setpoint:'],
  ['Débrief ·', 'Debrief ·'],
  ['Le corrigé optimise aussi la puissance, par pas de 5 kW, et valorise l’énergie restante.', 'The reference solution also optimises power in 5 kW increments and accounts for remaining energy.'],
  ['Cette borne idéale utilise le PV réel après coup ; un EMS réel travaille avec la prévision et son incertitude.', 'This ideal benchmark uses actual PV after the fact; a real EMS works with the forecast and its uncertainty.'],
  ['Les barres pleines sont vos décisions ; le contour violet indique la consigne optimale. Le SOC joué devient orange pendant une charge et vert pendant une décharge.', 'Solid bars are your decisions; the purple outline is the optimal setpoint. Your SOC is orange while charging and green while discharging.'],
  ['Comparaison équitable : chaque stratégie est ramenée au SOC initial de 45 % avant le bilan.', 'Fair comparison: each strategy is returned to the initial 45% SOC before its results are assessed.'],
  ['Référence EMS normalisée :', 'Normalised EMS reference:'],
  ['Charge seulement sur surplus PV ; décharge dès qu’il y a un besoin.', 'Charge only from PV surplus; discharge whenever there is demand.'],
  ['Charge sur surplus PV ; décharge seulement au-delà de 35 kW d’import.', 'Charge from PV surplus; discharge only above 35 kW of grid imports.'],
  ['SOC final brut :', 'Raw final SOC:'], ['rééquilibrage compté :', 'rebalancing included:'],
];

function translate(value: string) {
  if (translations[value]) return translations[value];
  let next = value;
  for (const [fr, en] of longer) next = next.replaceAll(fr, en);
  // French uses kWc (kilowatt-crête); the international English notation is kWp.
  next = next.replaceAll('kWc', 'kWp');
  next = next
    .replace(/^À (\d+h) :/, 'At $1:')
    .replace('Réserve :', 'Reserve:')
    .replace('Énergie du profil :', 'Profile energy:')
    .replace('kWh / 24 h', 'kWh / 24 h')
    .replace('Consigne effective :', 'Effective setpoint:')
    .replace('Votre coût est proche de la référence : vos arbitrages ont bien tenu compte des périodes coûteuses.', 'Your cost is close to the reference: your trade-offs took costly periods into account.')
    .replace(/Votre coût dépasse la référence de ([^.]+)\. Repérez les heures où la batterie pouvait remplacer un import cher\./, 'Your cost exceeds the reference by $1. Identify hours when the battery could have replaced expensive imports.')
    .replace(/Vous avez importé ([^.]+) de plus que la référence\. Dans un bâtiment réel, une réserve trop faible avant une pointe peut accroître la facture et la puissance appelée\./, 'You imported $1 more than the reference. In a real building, a reserve that is too low before a peak can increase the bill and peak demand.')
    .replace('Vos imports sont proches de la référence : la batterie a été mobilisée aux moments utiles.', 'Your imports are close to the reference: the battery was used at useful times.')
    .replace('Une partie importante du solaire a été exportée. Une charge pendant le surplus, ou un stockage légèrement plus grand, peut valoriser davantage cette production locale.', 'A significant share of solar was exported. Charging during surplus, or slightly larger storage, can make better use of this local production.')
    .replace('Vous avez bien valorisé la production solaire locale et limité les exports évitables.', 'You made good use of local solar production and limited avoidable exports.')
    .replace('Application réelle :', 'Real-world application:')
    .replace('un EMS combine prévisions PV et consommation, tarifs, contraintes batterie et objectifs du site. L’optimum présenté ici connaît le PV réalisé après coup : il sert de référence pour discuter de la valeur — et des limites — d’un pilotage prédictif.', 'an EMS combines PV and load forecasts, tariffs, battery constraints and site objectives. The optimum shown here knows actual PV after the fact: it is a benchmark for discussing the value — and limits — of predictive control.');
  return next;
}

export function useEnglishTranslations() {
  useEffect(() => {
    const english = window.location.pathname === '/en' || window.location.pathname.startsWith('/en/') || new URLSearchParams(window.location.search).get('lang') === 'en';
    if (!english) return;
    document.documentElement.lang = 'en';
    const apply = () => {
      const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
      const nodes: Text[] = [];
      while (walker.nextNode()) nodes.push(walker.currentNode as Text);
      nodes.forEach(node => { const value = node.nodeValue ?? ''; const result = translate(value); if (result !== value) node.nodeValue = result; });
      document.querySelectorAll<HTMLAnchorElement>('a[href^="/"]:not([data-language-switcher])').forEach(link => {
        const href = link.getAttribute('href') ?? '';
        if (!href.startsWith('/en')) link.href = `/en${href === '/' ? '' : href}`;
      });
    };
    apply();
    const observer = new MutationObserver(apply);
    observer.observe(document.body, { childList: true, subtree: true, characterData: true });
    return () => observer.disconnect();
  }, []);
}
